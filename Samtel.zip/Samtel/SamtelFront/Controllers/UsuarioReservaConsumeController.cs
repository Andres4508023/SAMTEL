﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using BackendSamtelDomain.Models;
using LibService.UsuarioReservaService;
using Microsoft.AspNetCore.Mvc.Rendering;

namespace SamtelFront.Controllers
{
    public class UsuarioReservaConsumeController : Controller
    {
        private readonly IUsuarioReservaServiceConsume _usuarioReservaServiceConsume;
        private readonly SamtelContext _samtelContext;

        public UsuarioReservaConsumeController (IUsuarioReservaServiceConsume usuarioReservaServiceConsume, SamtelContext samtelContext)
        {
            _usuarioReservaServiceConsume = usuarioReservaServiceConsume;
            _samtelContext = samtelContext;
        }

        public async Task<IActionResult> GetUsuarioReservaList(DateTime FechaEntrada, DateTime FechaSalida)
        {
            var FechaEntradaF = FechaEntrada.ToString("yyyy-MM-dd");
            var FechaSalidaF = FechaSalida.ToString("yyyy-MM-dd");

            if (FechaEntradaF == "0001-01-01" || FechaSalidaF == "0001-01-01")
            {
                var myDate = DateTime.Now;
                var oldDate = myDate.AddYears(-1);

                var list = await _usuarioReservaServiceConsume.GetUsuarioReservaList(oldDate, DateTime.Now);
                ViewBag.List = list;
            }
            else
            {
                var list = await _usuarioReservaServiceConsume.GetUsuarioReservaList(FechaEntrada, FechaSalida);
                ViewBag.List = list;
            }
            return View();          
        }

        public IActionResult CreateUsuarioReserva()
        {
            var lista = _samtelContext.Hotel;
            List<Hotel> listHotel = lista.ToList();
            ViewBag.listHotel = new SelectList(listHotel, "IdHotel", "NombreHotel");
            return View();
        }

        [HttpPost]
        public async Task<IActionResult> CreateUsuarioReserva(UsuarioReservaView model)
        {
            bool response = await _usuarioReservaServiceConsume.SaveUsuarioReserva(model);
            return RedirectToAction("GetUsuarioReservaList");
        }

        //[HttpPost]
        public async Task<IActionResult> EditUsuarioReserva(string id)
        {
            try
            {
                var model = new UpdateReservaHotelView();
                model.Identificacion = id;
                bool response = await _usuarioReservaServiceConsume.UpdateUsuarioReserva(model);
                
                    return RedirectToAction("GetUsuarioReservaList");
            }

            catch (Exception ex)
            {
                throw new Exception(ex.Message);
            }
        }
    }
}