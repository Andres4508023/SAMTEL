﻿using System;
using System.Collections.Generic;
using System.Text;

namespace BackendSamtelDomain.Models
{
    public class UpdateReservaHotelView
    {
        public string Identificacion { get; set; }
    }
}
