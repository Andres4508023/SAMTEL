﻿using System;

namespace LibService
{
    public class AppSetting
    {
        public string WebAPILink { get; set; }
    }
}
