﻿using System;
using System.Collections.Generic;
using System.Text;
using System.Threading.Tasks;
using BackendSamtelDomain.Models;

namespace LibService.UsuarioReservaService
{
    public interface IUsuarioReservaServiceConsume
    {
        Task<List<UsuarioReservaView>> GetUsuarioReservaList(DateTime FechaEntrada, DateTime FechaSalida);
        Task<bool> SaveUsuarioReserva(UsuarioReservaView model);
        Task<bool> UpdateUsuarioReserva(UpdateReservaHotelView model);
    }
}
